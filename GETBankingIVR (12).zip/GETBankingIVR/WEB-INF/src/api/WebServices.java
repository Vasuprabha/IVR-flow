package api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import com.avaya.sce.runtimecommon.SCESession;

public class WebServices {

	private static SCESession mySession;

	static HttpClient httpClient = HttpClientBuilder.create().build();

	public String verifyIdPassword(String url) {
		try {
			HttpGet getRequest = new HttpGet("http://localhost:8888/" + url);
			getRequest.addHeader("accept", "application/json");
			HttpResponse response = httpClient.execute(getRequest);
			String output;
			if (response == null) {
				System.out.println(response);
				return null;
			} else {
				BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				System.out.println("Output from Server .... \n");
				output = br.readLine();
				System.out.println("Responce:" + output);
				return output;
			}
		} catch (ClientProtocolException e) {
			System.out.println("Exception: " + e);
			return "noapi";
		} catch (IOException e) {
			System.out.println("Exception: " + e);
			return "noinput";
		} catch (Exception e) {
			System.out.println("Exception: " + e);
			return null;
		}
	}

	public  float checkBalance(String url) {
		try {
			HttpGet getRequest = new HttpGet("http://localhost:8888/" + url);
//			HttpGet getRequest = new HttpGet(
//					"http://localhost:8888/bankingService/checkingBalanceAmount?customerId=1&accountNumber=123456&password=1234");
			getRequest.addHeader("accept", "application/json");
			HttpResponse response = httpClient.execute(getRequest);
			if (response == null) {
				System.out.println(response);
				return 404;
			} else {
				BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String output;
				System.out.println("Output from Server .... \n");
				output = br.readLine();
				System.out.println(output);
				return Float.parseFloat(output);
			}

		} catch (ClientProtocolException e) {
			System.out.println("E1" + e);
			return 0;
		} catch (IOException e) {
			System.out.println("E2" + e);
			return 500;
		} catch (Exception e) {
			System.out.println("E3" + e);
			return 0;

		}
		// return 0;

	}

//	public static void main(String[] args) {
//		String url = "/customerIdAndPasswordVerification?customerId=" + 1 + "&password=" + 1234;
//
//		checkBalance(url);
//	}
}
