package dbo;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;

public class ConnectionPooling {

	String Driver = null;
	String Dburl = null;
	String username = null;
	String password = null;

	private static BasicDataSource dataSource = new BasicDataSource();

	public BasicDataSource dbConnection() throws IOException {

		try {
			FileInputStream file = null;
			file = new FileInputStream("D:\\AVAYA\\GETBankingIVR\\data\\db.properties");
			Properties property = new Properties();
			property.load(file);

			Driver = property.getProperty("Dbdriver");
			Dburl = property.getProperty("Dburl");
			username = property.getProperty("Dbusername");
			password = property.getProperty("Dbpassword");
			System.out.println("Property file worked");
			dataSource = new BasicDataSource();
			dataSource.setDriverClassName(Driver);
			dataSource.setUrl(Dburl);
			dataSource.setUsername(username);
			dataSource.setPassword(password);

			dataSource.setMinIdle(5);
			dataSource.setMaxIdle(10);
			dataSource.setMaxTotal(25);
		} catch (Exception e) {
			System.out.println(e);

		}
		return dataSource;
	}

	public Connection source() throws SQLException {
		Connection connection = null;
		try {
			dataSource = new ConnectionPooling().dbConnection();
			connection = dataSource.getConnection();
			System.out.println("Connection Created");
			return connection;

		} catch (Exception e) {
			System.out.println("Exception in Connection Operation" + e);
			return connection;

		}
	}
}
