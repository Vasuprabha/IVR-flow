package api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

public class WebServices {

	private SCESession mySession;

	HttpClient httpClient = HttpClientBuilder.create().build();
	//String output;

	public String verifyIdPassword(String url) {
		try {

			HttpGet getRequest = new HttpGet("http://localhost:8888/bankingService" + url);
			getRequest.addHeader("accept", "application/json");
			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			} else {

				BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String output;
				System.out.println("Output from Server .... \n");
				output = br.readLine();
				System.out.println(output);
				return output;

			}

		} catch (IOException e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "IOException occured " + e.getLocalizedMessage(), mySession);
			return null;

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception occured while in api " + e.getLocalizedMessage(),
					mySession);
			return null;

		}
		//return output;

	}

	public float checkBalance(String url) {
		try {

			HttpGet getRequest = new HttpGet("http://localhost:8888/bankingService" + url);
			getRequest.addHeader("accept", "application/json");
			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			} else {

				BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String output;
				System.out.println("Output from Server .... \n");
				output = br.readLine();
				System.out.println(output);
				return Float.parseFloat(output);
			}

		} catch (IOException e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "IOException occured " + e.getLocalizedMessage(), mySession);
			return 0;

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception occured while in api " + e.getLocalizedMessage(),
					mySession);
			return 0;

		}
	}
}
