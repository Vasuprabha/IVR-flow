package dynamic;

import java.util.ArrayList;
import java.util.List;

public class Transaction {

	public List<String> TransactionType() {

		List<String> transaction = new ArrayList<String>();
		transaction.add("Transaction1");
		transaction.add("Transaction2");
		transaction.add("Transaction3");
		transaction.add("Transaction4");
		transaction.add("Transaction5");
		transaction.add("Transaction6");
		transaction.add("Transaction7");
		transaction.add("Transaction8");
		transaction.add("Transaction9");
		transaction.add("Transaction10");
		transaction.add("Transaction11");
		transaction.add("Transaction12");
		transaction.add("Transaction13");
		transaction.add("Transaction14");
		transaction.add("Transaction15");
		transaction.add("Transaction16");
		return transaction;
	}


	public static void main(String[] args) {
		try {
			Transaction t = new Transaction();
			List<String> transactionType = t.TransactionType();
			System.out.println(transactionType);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
