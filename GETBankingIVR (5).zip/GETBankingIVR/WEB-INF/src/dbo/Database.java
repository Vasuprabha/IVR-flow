package dbo;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
//import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;

public class Database {
	private static BasicDataSource dataSource = null;
	String Driver = null;
	String Dburl = null;
	String username = null;
	String password = null;

	public BasicDataSource dbConnection() throws IOException {
		FileInputStream file = new FileInputStream("D:\\AVAYA\\GETBankingIVR\\data\\db.properties");
		Properties property = new Properties();
		property.load(file);
		Driver = property.getProperty("Dbdriver");
		Dburl = property.getProperty("Dburl");
		username = property.getProperty("Dbusername");
		password = property.getProperty("Dbpassword");
		System.out.println("Property file worked");
		dataSource = new BasicDataSource();
		dataSource.setDriverClassName(Driver);
		dataSource.setUrl(Dburl);
		dataSource.setUsername(username);
		dataSource.setPassword(password);

		dataSource.setMinIdle(5);
		dataSource.setMaxIdle(10);
		dataSource.setMaxTotal(25);
		return dataSource;
	}

//	public ResultSet connectionPool(String query) throws SQLException, IOException {
//
//		Connection connection = null;
//		Statement statement = null;
//		ResultSet rs = null;
//
//		connection = dbConnection().getConnection();
//		statement = connection.createStatement();
//		rs = statement.executeQuery(query);
//
//		return rs;
//
//	}

	public void update(String query) throws SQLException, IOException {

		Connection connection = null;
		Statement statement = null;

		connection = dbConnection().getConnection();
		statement = connection.createStatement();
		statement.execute(query);
	}


}
